---
layout: page
title: Magna arcu feugiat
image: images/pic01.jpg
style: wrapper spotlight style1
id: one
tagline: Lorem ipsum dolor sit amet, etiam lorem adipiscing elit. Cras turpis ante, nullam sit amet turpis non, sollicitudin posuere urna. Mauris id tellus arcu. Nunc vehicula id nulla dignissim dapibus. Nullam ultrices, neque et faucibus viverra, ex nulla cursus.
category: blog
---