---
layout: page
title: Tempus adipiscing
image: images/pic02.jpg
style: wrapper alt spotlight style2
id: two
tagline: Lorem ipsum dolor sit amet, etiam lorem adipiscing elit. Cras turpis ante, nullam sit amet turpis non, sollicitudin posuere urna. Mauris id tellus arcu. Nunc vehicula id nulla dignissim dapibus. Nullam ultrices, neque et faucibus viverra, ex nulla cursus.
category: blog
---