---
layout: post
title: Nisl placerat
date: 2016-07-20
tagline: Lorem ipsum dolor sit amet, consectetur adipiscing vehicula id nulla dignissim dapibus ultrices.
image: images/pic06.jpg"
category: blog
---